package com.example.myapplication.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.myapplication.DatePicker;
import com.example.myapplication.R;
import com.example.myapplication.SavedGames;
import com.example.myapplication.Rating;


public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Der Auslöser für den Button um die Activity "neuen Spieleabend anlegen" zu starten
        Button button1 = (Button) view.findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(),DatePicker.class);
                startActivity(in);
            }
        });

        // Der Auslöser für den Button um die Activity "angelegte Spiele ansehen" zu starten
        Button btn_saved_games = (Button) view.findViewById(R.id.btn_saved_games);
        btn_saved_games.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(), SavedGames.class);
                startActivity(in);
            }
        });

        // Der Auslöser für den Button um die Activity "bewerte ein Spieleabend" zu starten
        Button btn_rating = (Button) view.findViewById(R.id.btn_rating);
        btn_rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getActivity(), Rating.class);
                startActivity(in);
            }
        });
        // Endet hier
        return view;
    }

}