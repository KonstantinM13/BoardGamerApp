package com.example.myapplication;

public class Spiele {
    private String spiel;
    private String datum;
    private String zeit;

    public Spiele() {
    }

    public Spiele(String spiel, String datum, String zeit) {
        this.spiel = spiel;
        this.datum = datum;
        this.zeit = zeit;
    }

    public String getSpiel() {
        return spiel;
    }

    public String setSpiel(String trim) {return spiel;}


    public String getDatum() {
        return datum;
    }

    public String setDatum(String trim) {return datum;}



    public String getZeit() {
        return zeit;
    }
    public String setZeit(String trim) {return zeit;}



}
