package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{
    private List<Spiele>listData;

    public MyAdapter(List<Spiele> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_data,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Spiele ld=listData.get(position);
        holder.spielname.setText(ld.getSpiel());
        holder.datum.setText(ld.getDatum());
        holder.zeit.setText(ld.getZeit());
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView spielname,datum,zeit;
        public ViewHolder(View itemView) {
            super(itemView);
            spielname=(TextView)itemView.findViewById(R.id.spielname);
            datum=(TextView)itemView.findViewById(R.id.datum);
            zeit=(TextView)itemView.findViewById(R.id.zeit);
        }
    }
}